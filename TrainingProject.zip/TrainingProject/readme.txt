To open this project you should have intelliJ installed to open the project

After opeing IntelliJ install Scala plugin then open this project

To see the graphs you should install python then 
1. plotly using pip install plotly
2. dash using pip install dash
3. dash-bootstrap-components using pip install dash-bootstrap-components


After installing everything just run Project.py file

