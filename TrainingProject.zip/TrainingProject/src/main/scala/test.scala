import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions.{avg, desc, max, min, round}

object test {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("Car Price Project")
      .master("local[2]")
      .getOrCreate()
    spark.conf.set("spark.sql.shuffle.partitions", 2)
    val car1_df = spark.read
      .format("csv")
      .option("header", value = true)
      .option("inferSchema", value = true)
      .csv("data/Input/X_test.csv")

    val car2_df = spark.read
      .format("csv")
      .option("header", value = true)
      .option("inferSchema", value = true)
      .csv("data/Input/X_train.csv")

    val car1_price_df = spark.read
      .format("csv")
      .option("header", value = true)
      .option("inferSchema", value = true)
      .csv("data/Input/y_test.csv")

    val car2_price_df = spark.read
      .format("csv")
      .option("header", value = true)
      .option("inferSchema", value = true)
      .csv("data/Input/y_train.csv")

    val car1_specification = car1_df.join(car1_price_df, "carID")
    val car2_specification = car2_df.join(car2_price_df, "carID")
    val cars = car1_specification.union(car2_specification)

    // Brand and Model Wise Price
    //    select brand,model,min(price) as "Minimum Price",round(avg(price),2) as "Average Price",max(price) as "Maximum Price"
    //    from cars group by brand,model order by brand,model limit 10;


        val brandModelPrice = cars
      .groupBy("brand","model")
      .agg(
        min("price").as("Min Price"),
        round(avg("price"),2).as("Average Price"),
        max("price").as("Max Price")
      )
      .sort("brand","Average Price")

    // Brand Wise Price

    val brandPrice = cars
      .groupBy("brand")
      .agg(
        min("price").as("Min Price"),
        round(avg("price"),2).as("Average Price"),
        max("price").as("Max Price")
      )
      .sort("Average Price")

    // Fueltype wise Average Price
    //    select fuelType,min(price) as "Minimum Price",round(avg(price),2) as "Average Price",max(price) as "Maximum Price"
    //    from cars group by fuelType order by 3 desc;

    val fuelTypePrice = cars
      .groupBy("fuelType")
      .agg(
        min("price").as("Min Price"),
        round(avg("price"),2).as("Average Price"),
        max("price").as("Max Price")
      )
    .sort(desc("Average Price"))

    //fueltype and Brand wise Average Price
    //    select brand,fuelType,min(price) as "Minimum Price",round(avg(price),2) as "Average Price",max(price) as "Maximum Price"
    //    from cars group by brand,fuelType order by 1,2;

    val fuelTypeBrandPrice = cars
      .groupBy("brand", "fuelType")
      .agg(
        min("price").as("Min Price"),
        round(avg("price"), 2).as("Average Price"),
        max("price").as("Max Price")
      )
      .sort( "Average Price")

// Year wise brand price

    val yearWiseBrandPrice = cars
       .groupBy("brand","year")
       .agg(
         min("price").as("Min Price"),
         round(avg("price"),2).as("Average Price"),
         max("price").as("Max Price")
       )
      .where("year>2001")
     .sort("year")

    // No. of cars in each brand

    val distBrandAndModel=cars
      .select("brand","model")
      .distinct()
      .sort("brand")

    val carsInEachBrand=distBrandAndModel
      .groupBy("brand")
      .count()

    //Total cars of each brand
      val totalCars=cars
        .groupBy("brand")
        .count()
        .sort(desc("count"))

    //Best Selling model of each brand

    val first=cars
      .groupBy("brand","model")
      .count()
      .sort(desc("count"))

    val second=first
      .groupBy("brand")
      .max("count")

    val bestSellingModel=second.alias("a").join(first.alias("b"),second("max(count)")===first("count"),"inner")
      .select("a.brand","b.model","b.count").sort(desc("b.count"))


    //Worst Selling model of each brand

    val first1=cars
      .groupBy("brand","model")
      .count()
      .sort("count")

    val second1=first
      .groupBy("brand")
      .min("count")

    val worstSellingModel=second1.alias("a1").join(first1.alias("b1"),second1("min(count)")===first1("count"),"inner")
      .select("a1.brand","b1.model","b1.count").where("a1.brand=b1.brand").sort("b1.count")

    //cars based on transmission type
    val transmissionType=cars
      .groupBy("brand","transmission")
      .count()
      .sort("brand","transmission")

    //Price base on mileage

    val mileageData=cars
      .select("brand","mileage","price")

    //Popular transmission type in last decade
    //select year,transmission,count(*) from cars where transmission <> 'other' and year>2000 group by year,transmission order by year;
      val yearlyTransmission=cars
        .groupBy("year","transmission")
        .count()
        .where("transmission <> 'Other' and year>2000")
        .sort("year")

    //Output Section

    fuelTypePrice.coalesce(1)
      .write
      .format("csv")
      .mode(SaveMode.Overwrite)
      .option("header","true")
      .option("path", "data/Outputs/fuelTypePrice")
      .save()

    brandModelPrice.coalesce(1)
      .write
      .format("csv")
      .mode(SaveMode.Overwrite)
      .option("header","true")
      .option("path", "data/Outputs/brandModelPrice")
      .save()

    brandPrice.coalesce(1)
      .write
      .format("csv")
      .mode(SaveMode.Overwrite)
      .option("header","true")
      .option("path", "data/Outputs/brandPrice")
      .save()

    fuelTypeBrandPrice.coalesce(1)
      .write
      .format("csv")
      .mode(SaveMode.Overwrite)
      .option("header","true")
      .option("path", "data/Outputs/fuelTypeBrandPrice")
      .save()

        yearWiseBrandPrice.coalesce(1)
      .write
      .format("csv")
      .mode(SaveMode.Overwrite)
      .option("header","true")
      .option("path", "data/Outputs/yearWiseBrandPrice")
      .save()

            carsInEachBrand.coalesce(1)
          .write
          .format("csv")
          .mode(SaveMode.Overwrite)
          .option("header","true")
          .option("path", "data/Outputs/carsInEachBrand")
          .save()

            totalCars.coalesce(1)
          .write
          .format("csv")
          .mode(SaveMode.Overwrite)
          .option("header","true")
          .option("path", "data/Outputs/totalCars")
          .save()

    bestSellingModel.coalesce(1)
          .write
          .format("csv")
          .mode(SaveMode.Overwrite)
          .option("header","true")
          .option("path", "data/Outputs/bestSellingModel")
          .save()

    worstSellingModel.coalesce(1)
      .write
      .format("csv")
      .mode(SaveMode.Overwrite)
      .option("header","true")
      .option("path", "data/Outputs/worstSellingModel")
      .save()

        transmissionType.coalesce(1)
          .write
          .format("csv")
          .mode(SaveMode.Overwrite)
          .option("header","true")
          .option("path", "data/Outputs/transmissionType")
          .save()


    mileageData.coalesce(1)
        .write
        .format("csv")
        .mode(SaveMode.Overwrite)
        .option("header","true")
        .option("path", "data/Outputs/mileageData")
        .save()

    yearlyTransmission.coalesce(1)
      .write
      .format("csv")
      .mode(SaveMode.Overwrite)
      .option("header","true")
      .option("path", "data/Outputs/yearlyTransmission")
      .save()


  }
}
